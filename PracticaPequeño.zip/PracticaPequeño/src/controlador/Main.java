package controlador;
public class Main {
    
    public static void main(String[] args) {
        ControladorMedicamento.mostrar();
    }
    
}
